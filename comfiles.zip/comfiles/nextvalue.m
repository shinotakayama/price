function v = nextvalue(x, int, b, m, f)

v = m(int)*(x - b(int)) + f(int);